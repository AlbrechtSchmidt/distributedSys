
#define S_PORT 7777

#define ENDE "XXX"

#define RESET "RRR"

