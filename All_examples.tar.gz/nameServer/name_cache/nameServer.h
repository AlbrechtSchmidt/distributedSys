
#define S_PORT 7777

#define ENDE "BYE"
#define END_OF_CMD "!"

