#include <stdio.h> 
#include <fcntl.h> 
#include <sys/time.h> 
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define FALSE 0
#define TRUE  1
#define AND &&
#define OR ||

