#include <stdio.h> 
#include <sys/time.h> 

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define FALSE 0
#define TRUE  1
#define AND &&
#define OR ||

#define SERVER_PORT 7777

