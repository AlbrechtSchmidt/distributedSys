#include <stdio.h> 
#include <fcntl.h> 
#include <sys/time.h> 

#define FALSE 0
#define TRUE  1
#define AND &&

#define LOCKFILE "LockServer"
