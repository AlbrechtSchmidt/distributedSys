/* Hier steht der Pfad des gemeinsammen
   Kommunikationsverzeichnisses         */

#define KommuDIR "."

