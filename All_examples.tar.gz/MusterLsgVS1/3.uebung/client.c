#include "vertsys.h"

main(argc,argv) int argc; char* argv[];
{
	int             sd;
	struct sockaddr_in server;
	struct hostent *hp,*gethostbyname();
	char            buf[30],name[20];
	
	int		i; /*zusaetzlich fuer die UDP - Version*/

	if (argc <=1 ) {
           printf("   Fehler: Mindestens einen Parameter angeben!\n");
           printf("     z.B.: client Date oder client Time oder client DateAndTime\n");
           printf("     oder: client Date \"hostname\"\n\n");
           exit(-1);
        }
	sd = socket(AF_INET, SOCK_DGRAM, 0);	/* fuer UDP - Verbindung*/ 

	if (argc == 3) hp = gethostbyname(argv[2]);
	else {	gethostname(name,20);
		hp = gethostbyname(name);
	}
	server.sin_family = AF_INET;
	bcopy((char *) hp->h_addr, (char *) &server.sin_addr, hp->h_length);
	server.sin_port = htonl(SERVER_PORT);
	
	sendto(sd, argv[1],strlen(argv[1]), 0, (struct sockaddr *)&server,
	sizeof(server));
	i = sizeof(server);
	recvfrom(sd, buf, sizeof(buf), 0, (struct sockaddr *)&server, &i);
	printf("   Request: %s\n   Answer : %s\n",argv[1], buf);
	close(sd);
}
