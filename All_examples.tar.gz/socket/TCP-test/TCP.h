
#define S_PORT 7777

#define ENDE "XXX"

#define MAX_COUNT 10000

